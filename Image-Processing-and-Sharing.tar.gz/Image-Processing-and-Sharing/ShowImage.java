import javax.swing.ImageIcon;
import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class ShowImage extends JDialog
{
	public ShowImage(java.awt.Frame parent,boolean modal)
	{
		super(parent,modal);
		initComponents();
	}
	public void set(ImageIcon icon)
	{
		lb.setIcon(icon);
	}
	
	@SuppressWarnings("unchecked")
	private void initComponents()
	{
		lb=new JLabel();
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		lb.setHorizontalAlignment(SwingConstants.CENTER);
		
		GroupLayout layout=new GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup
		(
			layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(lb,GroupLayout.DEFAULT_SIZE,350,Short.MAX_VALUE));
			layout.setVerticalGroup
			(
				layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(lb,GroupLayout.DEFAULT_SIZE,231,Short.MAX_VALUE));
				pack();
				setLocationRelativeTo(null);
	}
			public static void main(String args[])
			{
				try{
					for(javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
					{
						if("Nimbus".equals(info.getName()))
						{
							javax.swing.UIManager.setLookAndFeel(info.getClassName());
							break;
						}
					}
				}catch(ClassNotFoundException ex)
				{
					java.util.logging.Logger.getLogger(ShowImage.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
				}
				catch(InstantiationException ex)
				{
					java.util.logging.Logger.getLogger(ShowImage.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
				}
				catch(IllegalAccessException ex)
				{
					java.util.logging.Logger.getLogger(ShowImage.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
				}
				catch(UnsupportedLookAndFeelException ex)
				{
					java.util.logging.Logger.getLogger(ShowImage.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
				}	
				
				EventQueue.invokeLater(new Runnable(){
				public void run(){
					ShowImage dialog = new ShowImage(new JFrame(),true);
					dialog.addWindowListener(new WindowAdapter(){
					//@Override
					public void WindowClosing(WindowEvent e){
					System.exit(0);
					}
					});
					dialog.setVisible(true);
					}
					});
				}
				private JLabel lb;
}
