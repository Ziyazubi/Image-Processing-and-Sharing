import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.*;

class baZIra extends JFrame implements MouseMotionListener,MouseListener
{

	int x,y;
	Connection con = null;
	Statement stmt = null;
	PreparedStatement psl = null;
	ResultSet rs;
	Random rn;
	int value;
		baZIra(){
		
		rn= new Random();
		value=rn.nextInt(100);
		try
		{
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection("jdbc:postgresql://192.168.16.1/ty8843","ty8843","");
			if(con==null)
				System.out.println("Connection Failed");
			else
			{
				System.out.println("Connection Successful");
			}
		}
		catch(Exception e)
		{}

	
		addMouseListener(this);
		addMouseMotionListener(this);
		
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void mouseDragged(MouseEvent e)
	{	
	}
	
	public void mouseReleased(MouseEvent e)
	{	
	}
	public void mouseMoved(MouseEvent e)
	{	
	}
	public void mousePressed(MouseEvent e)
	{	
	}
	public void mouseEntered(MouseEvent e)
	{	
	}
	public void mouseExited(MouseEvent e)
	{	
	}
	public void mouseClicked(MouseEvent e)
	{
		x=e.getX();
		y=e.getY();
		System.out.println(" X: "+x+" Y "+y);
		
			try
			{
				
				psl = con.prepareStatement("insert into login values(?,?,?)");
				
				psl.setInt(1,value);
				psl.setInt(2,x);
				psl.setInt(3,y);
		
				int f = psl.executeUpdate();
				if(f>0)
				{
					JOptionPane.showMessageDialog(null,"Data updated successfully","Success",JOptionPane.PLAIN_MESSAGE);                    
				}
			}
			catch(Exception e2)
			{}		 
	}
	
	
	public static void main(String args[])
	{
		new baZIra();
	}	
	
}
