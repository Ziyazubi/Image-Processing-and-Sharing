import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import javax.swing.event.*;
import java.awt.color.*;
import java.awt.geom.*;
import javax.imageio.stream.*;

public class ProspecT extends ImageProcessing implements ActionListener, MouseMotionListener,MouseListener,AdjustmentListener
{
	BufferedImage im,FImg;
	String Imgfilename;
	JMenuBar JMBar;
	JMenu JMFile,JMedit,JMimage,JMwindows,JMabout;
	JMenuItem JMIOpen,JMIclose,JMIsave,JMIsaveAs,JMIexit,JMIundo,JMIredo,JMIcopy,JMIpaste;
	JMenuItem JMchangeColor,JMmeanFilter,JMmedianFilter,JMscale,JMsetColorXY;
	JMenuItem JMItools,JMIinfo;
	JToolBar ToolsPanel;
	JDesktopPane desktop;
	JButton JBchangeColor,JBmeanFilter,JBmedianFilter,JBscale,JBsetColorXY,JBFilter,JB;
	JLabel lbR,lbG,lbB,lbXYrotXY;
	JLabel LBwidthscale,LBhightscale,lbXrotX,lbYrotY,LBChangeImag;
	JComboBox Chwidthscale,Chhightscale;
	JButton JBold,JBAply,JBchangeColorGetColor,JBRGB,JBmeanFilters,JBmedianFilters,JBscales,JBChangeImag,JBsetColorXYs,JBCOLORSET;
	JTextField txtR,txtG,txtB;
	
	JButton Receive,Share,JBaddtext,JBcompression,JBresize,JBrotate,JBtransparency,JBbright,JBreset;
	JLabel fromto1,fromto2,fromto3,fromto4,fromto5;
	int ScrenW,ScrenH;
	JLabel JLBlogo;
	JInternalFrame Tools,Info,share;
	public void Componentint()
	{
		Container container=getContentPane();
		container.setBackground(new Color(0xB2B2FC));
		desktop=new JDesktopPane();
		desktop.setDragMode(JDesktopPane.LIVE_DRAG_MODE);
		container.add(desktop,BorderLayout.CENTER);
		desktop.setBackground(new Color(240,240,245));
		Tools=new JInternalFrame("Tools",true,true,true,true);
		Tools.setBounds(5,5,55,300);
		Tools.putClientProperty("JInternalFrame.isPalette",Boolean.TRUE);
		Tools.setVisible(true);
		desktop.add(Tools,JDesktopPane.PALETTE_LAYER);
		Tools.setLayout(null);
		ImageIcon img;
		Image im,new_img;
		
		img=new ImageIcon("/exports/TYBG22/TYBG22/dropper.jpg");
		im=img.getImage();
		new_img=im.getScaledInstance(30,30,Image.SCALE_SMOOTH);
		img=new ImageIcon(new_img);
		
		JBchangeColor=new JButton(img);
		JBchangeColor.setToolTipText("ChangeColor");
		JBchangeColor.addActionListener(this);
		JBchangeColor.setBounds(10,5,30,30);
		Tools.add(JBchangeColor);
	
		img=new ImageIcon("/exports/TYBG22/TYBG22/effects2.jpg");
		im=img.getImage();
		new_img=im.getScaledInstance(30,30,Image.SCALE_SMOOTH);
		img=new ImageIcon(new_img);
			
		JBmedianFilter=new JButton(img);
		JBmedianFilter.setToolTipText("median filter");
		JBmedianFilter.addActionListener(this);
		JBmedianFilter.setBounds(10,40,30,30);
		Tools.add(JBmedianFilter);
	
		img=new ImageIcon("/exports/TYBG22/TYBG22/zi.jpg");
		im=img.getImage();
		new_img=im.getScaledInstance(30,30,Image.SCALE_SMOOTH);
		img=new ImageIcon(new_img);
			
		JBscale=new JButton(img);
		JBscale.setToolTipText("scale");
		JBscale.addActionListener(this);
		JBscale.setBounds(10,75,30,30);
		Tools.add(JBscale);
		
		img=new ImageIcon("/exports/TYBG22/TYBG22/effects.jpg");
		im=img.getImage();
		new_img=im.getScaledInstance(30,30,Image.SCALE_SMOOTH);
		img=new ImageIcon(new_img);
		
		JBmeanFilter=new JButton(img);
		JBmeanFilter.setToolTipText("mean filter");
		JBmeanFilter.addActionListener(this);
		JBmeanFilter.setBounds(10,110,30,30);
		Tools.add(JBmeanFilter);
		
		img=new ImageIcon("/exports/TYBG22/TYBG22/shape.jpg");
		im=img.getImage();
		new_img=im.getScaledInstance(30,30,Image.SCALE_SMOOTH);
		img=new ImageIcon(new_img);
		
		JBsetColorXY=new JButton(img);
		JBsetColorXY.setToolTipText("Draw Rectangle");
		JBsetColorXY.addActionListener(this);
		JBsetColorXY.setBounds(10,145,30,30);
		Tools.add(JBsetColorXY);
		
		img=new ImageIcon("/exports/TYBG22/TYBG22/effects-or-choose-colour.jpg");
		im=img.getImage();
		new_img=im.getScaledInstance(30,30,Image.SCALE_SMOOTH);
		img=new ImageIcon(new_img);
			
		JBFilter=new JButton(img);
		JBFilter.setToolTipText("Manual Filter");
		JBFilter.addActionListener(this);
		JBFilter.setBounds(10,185,30,30);
		Tools.add(JBFilter);
		
			
	       img=new ImageIcon("/exports/TYBG22/TYBG22/text-add.jpg");
		im=img.getImage();
		new_img=im.getScaledInstance(30,30,Image.SCALE_SMOOTH);
		img=new ImageIcon(new_img);
		JBaddtext=new JButton(img);
		JBaddtext.setToolTipText("Add Text");
		JBaddtext.addActionListener(this);
		JBaddtext.setBounds(10,220,30,30);
		Tools.add(JBaddtext);
		
		ScrenW=(int)(Toolkit.getDefaultToolkit().getScreenSize().getWidth());
		ScrenH=(int)(Toolkit.getDefaultToolkit().getScreenSize().getHeight());
	
		share=new JInternalFrame("Share and Recive",true,true,true,true);
		
		int Wi=ScrenW-120;
		share.setBounds(Wi,500,100,130);
		
		share.putClientProperty("JInternalFrame.isPalette",Boolean.TRUE);
		share.setVisible(true);
		desktop.add(share,JDesktopPane.PALETTE_LAYER);
		share.setLayout(null);
		
		Share=new JButton("Share");
		Share.setToolTipText("Share Image");
		Share.addActionListener(this);
		Share.setBounds(5,5,90,30);
		share.add(Share);
		
		Receive=new JButton("Receive");
		Receive.setToolTipText("Receive Image");
		Receive.addActionListener(this);
		Receive.setBounds(5,80,90,30);
		share.add(Receive);
	
	
	
		
		Info=new JInternalFrame("Position",true,true,true,true);
	
		
		Wi=ScrenW-175;
		Info.setBounds(Wi,5,170,170);
		Info.putClientProperty("JInternalFrame.isPalette",Boolean.FALSE);
		
		Info.setVisible(true);
		
		desktop.add(Info,JDesktopPane.PALETTE_LAYER);
		Info.setLayout(null);		
		JLabel lbinfo=new JLabel("cursor position");
		lbinfo.setBounds(20,10,180,20);
		Info.add(lbinfo);
		
		JLabel lbX=new JLabel("X");
		lbX.setBounds(10,40,20,20);
	
		Info.add(lbX);
			
		JLabel lbY=new JLabel("Y");
		lbY.setBounds(10,65,20,20);
		Info.add(lbY);
			
		txtX=new JTextField();
		txtX.setBounds(35,40,75,20);
		txtX.setEditable(false);
		Info.add(txtX);
		
		txtY=new JTextField();
		txtY.setBounds(35,65,75,20);
		txtY.setEditable(false);
		Info.add(txtY);
			
		JLabel lbcurd=new JLabel("current win");
		lbcurd.setBounds(10,90,84,20);
		Info.add(lbcurd);
		
		JLabel lbwin=new JLabel("total win");
		lbwin.setBounds(10,100,83,20);
		Info.add(lbwin);	
		
		lbtxtcurd=new JLabel("0");
		lbtxtcurd.setBounds(100,90,80,20);
		Info.add(lbtxtcurd);	
		
		lbtxtwin=new JLabel("0");
		lbtxtwin.setBounds(100,110,80,20);
		Info.add(lbtxtwin);	
	
		JBCOLORSET=new JButton();
		JBCOLORSET.setBounds(110,100,20,20);
		JBCOLORSET.setBackground(new Color(0xFF0000));
		JBCOLORSET.addActionListener(this);
		Info.add(JBCOLORSET);
		
		
		JMBar=new JMenuBar();
		JMFile=new JMenu("File");
		JMFile.setMnemonic('F');
		
		ImageIcon iconOpen=new ImageIcon("f2.jpg");
		JMIOpen=new JMenuItem("Open",iconOpen);
		JMIOpen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,InputEvent.CTRL_MASK));
		JMIOpen.addActionListener(this);
		JMFile.add(JMIOpen);
			
		ImageIcon iconClose=new ImageIcon("icon/close_16.gif");
		JMIclose= new JMenuItem("Close",iconClose);
		JMIclose.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,InputEvent.CTRL_MASK));
		JMIclose.addActionListener(this);
		JMFile.add(JMIclose);
		
		ImageIcon iconSave=new ImageIcon("icon/SAVE.png");
		JMIsave =new JMenuItem("Save",iconSave);
		JMIsave.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,InputEvent.CTRL_MASK));
		JMIsave.addActionListener(this);
		JMFile.add(JMIsave);
		
		ImageIcon iconSaveas=new ImageIcon("icon/SAVE-AS.png");
		JMIsaveAs= new JMenuItem("SaveAs",iconSaveas);
		JMIsaveAs.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,InputEvent.CTRL_MASK));
		JMIsaveAs.addActionListener(this);
		JMFile.add(JMIsaveAs);
		
		JMFile.addSeparator();
		
		ImageIcon iconExit=new ImageIcon("icon/CANCL_16.png");
		JMIexit= new JMenuItem("Exit",iconExit);
		JMIexit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,InputEvent.CTRL_MASK));
		JMIexit.addActionListener(this);
		JMFile.add(JMIexit);
		
		JMBar.add(JMFile);
		
		JMedit=new JMenu("Edit");
		JMedit.setMnemonic('E');
		
		ImageIcon iconUndo=new  ImageIcon("icon/UNDO_16.gif");
		JMIundo=new JMenuItem("SET IT",iconUndo);
		JMIundo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_U,InputEvent.CTRL_MASK));
		JMIundo.addActionListener(this);
		JMFile.add(JMIundo);
		
		ImageIcon iconRedo=new  ImageIcon("icon/UNDO_16.gif");
		JMIredo=new JMenuItem("SET IT",iconRedo);
		JMIredo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y,InputEvent.CTRL_MASK));
		JMIredo.addActionListener(this);
		JMFile.add(JMIredo);
		
		JMBar.add(JMedit);
		
		JMimage=new JMenu("Window");
		JMimage.setMnemonic('W');
		
		ImageIcon coloricon=new  ImageIcon("icon/cc.gif");
		JMchangeColor=new JMenuItem("Change Color",coloricon);
		JMchangeColor.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F2,0));
		JMchangeColor.addActionListener(this);
		JMimage.add(JMchangeColor);
		
		ImageIcon Mficon=new  ImageIcon("icon/mf.gif");
		JMmeanFilter=new JMenuItem("Mean",Mficon);
		JMmeanFilter.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F3,0));
		JMmeanFilter.addActionListener(this);
		JMimage.add(JMmeanFilter);
		
		ImageIcon Meficon=new  ImageIcon("icon/mef.gif");
		JMmedianFilter=new JMenuItem("Median",Meficon);
		JMmedianFilter.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4,0));
		JMmedianFilter.addActionListener(this);
		JMimage.add(JMmedianFilter);
		
		JMscale=new JMenuItem("Scale",null);
		JMscale.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5,0));
		JMscale.addActionListener(this);
		JMimage.add(JMscale);
		
		JMsetColorXY=new JMenuItem("Draw Rect",null);
		JMsetColorXY.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F6,0));
		JMsetColorXY.addActionListener(this);
		JMimage.add(JMsetColorXY);

		JMBar.add(JMimage);
		setJMenuBar(JMBar);
		
		ToolsPanel=new JToolBar("ToolsPanel");
		ToolsPanel.setBackground(new Color(0xEFE8EF));
		container.add(ToolsPanel,BorderLayout.NORTH);
		JBold=new JButton("Reset");
		JBold.addActionListener(this);
		JBAply = new JButton("Set It");
		JBAply.addActionListener(this);
		lbR=new JLabel("R");		
		lbG=new JLabel("G");		
		lbB=new JLabel("B");		
		
		txtR= new JTextField("B");
		txtG= new JTextField("R");		
		txtB= new JTextField("100");			
		
		JBRGB=new JButton("Change");
		JBRGB.addActionListener(this);
		
		JBmeanFilters=new JButton("Mean Filter");	
		JBmeanFilters.addActionListener(this);
		
		JBmedianFilters=new JButton("Median Filter");	
		JBmedianFilters.addActionListener(this);
	
		LBwidthscale=new JLabel("Width");
		LBhightscale=new JLabel("Height");
		
		Chwidthscale=new JComboBox();
		for(int i=1;i<20;i++)
			Chwidthscale.addItem(i+"");
			Chhightscale=new JComboBox();
		
		for(int i=1;i<20;i++)
			Chhightscale.addItem(i+"");
			
		JBscales=new JButton("scale");
		JBscales.addActionListener(this);
		
		lbrotX=new JLabel("0");
		lbYrotY=new JLabel(",");
		lbrotY=new JLabel("1");
		lbXYrotXY=new JLabel(")");
		
		fromto1=new JLabel("from(");
		fromto2=new JLabel(",");
		fromto3=new JLabel(")to(");
		fromto4=new JLabel(",");
		fromto5=new JLabel(")");
		
		fromx1=new JLabel("0");
		fromy1=new JLabel("0");
		fromx2=new JLabel("20");
		fromy2=new JLabel("20");
	
		JBsetColorXYs=new JButton("draw a rectangle");
		JBsetColorXYs.addActionListener(this);
	}
	public ProspecT()
	{
		super("bazira Image Editor 2.0");
		Componentint();
		setSize(ScrenW,ScrenH);
		setVisible(true);
		
		Image IconPro=Toolkit.getDefaultToolkit().getImage("icon/ss.png");
		setIconImage(IconPro);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	BufferedImage bufImage(String ImageName)
	{
		try{
			BufferedImage img1= ImageIO.read(new File(ImageName));
			return img1;
		}	
		catch(Exception e)
		{
			return null;
		}
	} 
	private void openImage(String strIm)
	{
		try{
			Imgfilename=strIm;
			FImg=bufImage(strIm);
			Viewer vi=new Viewer(100,50,FImg.getWidth()-20,FImg.getHeight()-20,FImg,strIm);
			allimages.add(vi);
			System.out.println(allimages.size()+"Total vector image size \n");
			
			desktop.add((Viewer)allimages.elementAt(allimages.size()-1),JDesktopPane.PALETTE_LAYER);
			System.out.println(allimages.size()+"Total vector image size \n");
			
			
		}
		catch(Exception e)
		{
		}
		
	}
	
	private void enableone(JMenuItem jm1,JButton jb1)
	{
		ToolsPanel.removeAll();
		ToolsPanel.add(JBold);
		
		if(jb1==JBchangeColor)
		{
			ToolsPanel.add(lbR);
			ToolsPanel.add(txtR);
			ToolsPanel.add(lbG);
			ToolsPanel.add(txtG);
			ToolsPanel.add(lbB);
			ToolsPanel.add(txtB);
			ToolsPanel.add(JBRGB);
		}
		else if(jb1==JBmeanFilter)
		{
			ToolsPanel.add(JBmeanFilters);
		}
		else if(jb1==JBmedianFilter)
		{
			System.out.print("\n Median filter....");
			ToolsPanel.add(JBmedianFilters);
		}
		else if(jb1==JBscale)
		{
			ToolsPanel.add(LBwidthscale);
			ToolsPanel.add(Chwidthscale);
			ToolsPanel.add(LBhightscale);
			ToolsPanel.add(Chhightscale);
			ToolsPanel.add(JBscales);
		}
		else if(jb1==JBsetColorXY)
		{
			ToolsPanel.add(fromto1);
			ToolsPanel.add(fromx1);
			ToolsPanel.add(fromto2);
			ToolsPanel.add(fromy1);
			ToolsPanel.add(fromto3);
			ToolsPanel.add(fromto2);
			ToolsPanel.add(fromto4);
			ToolsPanel.add(fromto2);
			ToolsPanel.add(fromto5);
			ToolsPanel.add(JBsetColorXYs);
		}
		ToolsPanel.add(JBAply);
	}
	public void updatechangeColor()
	{
		int temp=getIndexOfNumImage(currentWin);
		Viewer vo=(Viewer)allimages.elementAt(temp);
		vo.updateImage(changeColor(vo.img1,txtR.getText(),txtG.getText(),txtB.getText()));
	} 
	public void updatemeanFilters()
	{
		int temp=getIndexOfNumImage(currentWin);
		Viewer vo=(Viewer)allimages.elementAt(temp);
		vo.updateImage(meanFilter1(vo.img1));
	}
	public void updatemedianFilters()
	{
		int temp=getIndexOfNumImage(currentWin);
		Viewer vo=(Viewer)allimages.elementAt(temp);
		vo.updateImage(medianFilter(vo.img1));
	}
	public void updatescale(String width,String hight)
	{
	int temp=getIndexOfNumImage(currentWin);
	Viewer vo=(Viewer)allimages.elementAt(temp);
	vo.updateImage(scale(vo.img1,Integer.parseInt(width),Integer.parseInt(hight)));
	}
	public void updatesetColorXY(String x,String y,String toX,String toY)
	{
		int temp=getIndexOfNumImage(currentWin);
		Viewer vo=(Viewer)allimages.elementAt(temp);
		int corX=Integer.parseInt(x);
		int corY=Integer.parseInt(y);
		int cortoX=Integer.parseInt(toX);
		int cortoY=Integer.parseInt(toY);
		
		int w=Math.abs(cortoX-corX);
		int h=Math.abs(cortoY-corY);
		
		vo.updateImage(setColorToXY(vo.img1,corX,corY,cortoX,cortoY));
		
	}
	public void adjustmentValueChanged(AdjustmentEvent e)
	{
		try{
			
		}
		catch(Exception ex){}
	}
	public void resetOldImage()
	{
		int temp=getIndexOfNumImage(currentWin);
		Viewer vo=(Viewer)allimages.elementAt(temp);
		vo.setOldImage();
		repaint();
	}
	public void aplyNowImage()
	{
		int temp=getIndexOfNumImage(currentWin);
		Viewer vo=(Viewer)allimages.elementAt(temp);
		vo.newAply();
		repaint();
	}
	public void ClosedImage()
	{
		int temp=getIndexOfNumImage(currentWin);
		Viewer vo=(Viewer)allimages.elementAt(temp);
		try
		{
			vo.setClosed(true);
		}
		catch(Exception ex)
		{}
	}
	public void saveImages()
	{
		int temp=getIndexOfNumImage(currentWin);
		Viewer vo=(Viewer)allimages.elementAt(temp);
		try
		{
			ImageIO.write(vo.img1,"jpeg",new File(vo.path));
			vo.newAply();	
		}
		catch(Exception e)
		{
		}
	}
	public void saveAsImages()
	{
		int temp=getIndexOfNumImage(currentWin);
		Viewer vo=(Viewer)allimages.elementAt(temp);
		File fileName=new File(vo.path);
		JFileChooser fileChooser=new JFileChooser();
		
		fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		fileChooser.setSelectedFile(fileName);
		int returnVal=fileChooser.showSaveDialog(this);
		if(returnVal==JFileChooser.CANCEL_OPTION)
		{
			return;
		}
		else if(returnVal==JFileChooser.APPROVE_OPTION)
		{
			fileName=fileChooser.getSelectedFile();
			if(fileName.getName().indexOf('.')==-1)
				fileName=new File(fileName.getAbsolutePath()+".jpeg");
			try
			{
				ImageIO.write(vo.img1,"jpeg",new File(fileName.getAbsolutePath()));
				vo.newAply();
			}
			catch(Exception e)
			{}
		}
	}
	public void messageDialogExit()
	{
		System.exit(0);
	}
	public void actionPerformed(ActionEvent event)
	{
			if(event.getSource()==JMIOpen)
				openImage(FileChose());
			else if(event.getSource()==JMIclose)
				ClosedImage();
			else if(event.getSource()==JMIsave)
				saveImages();
			else if(event.getSource()==JMIsaveAs)
				saveAsImages();
			else if(event.getSource()==JMIundo)
				aplyNowImage();
			else if(event.getSource()==JMIredo)
				resetOldImage();
			
			else if(event.getSource()==JBold)
				resetOldImage();
			else if(event.getSource()==JBAply)
				aplyNowImage();
			else if(event.getSource()==JBRGB)
				updatechangeColor();
			else if(event.getSource()==JBmeanFilters)
				updatemeanFilters();
			else if(event.getSource()==JBmedianFilters)
				updatemedianFilters();
			else if(event.getSource()==JBscales)
				updatescale(Chwidthscale.getSelectedItem().toString(),Chhightscale.getSelectedItem().toString());			
			else if(event.getSource()==JBsetColorXYs)
				updatesetColorXY(fromx1.getText(),fromy1.getText(),fromx2.getText(),fromy2.getText());
			
			else if(event.getSource()==JBFilter)
			{
				int temp=getIndexOfNumImage(currentWin);
				
				Viewer vo=(Viewer)allimages.elementAt(temp);
			
				new baziraImageFilter(vo.sendimg(),temp);
			}
			else if(event.getSource()==Share)
			{
				int temp=getIndexOfNumImage(currentWin);
				Viewer vo=(Viewer)allimages.elementAt(temp);
			
				new ClientMachine(vo.sendimg());
			}
			else if(event.getSource()==Receive)
			{
				new ServerMachine();
			}

							
			else if((event.getSource()==JMchangeColor) || (event.getSource()==JBchangeColor))
				enableone(JMchangeColor,JBchangeColor);
			
			
			else if((event.getSource()==JMmeanFilter) || (event.getSource()==JBmeanFilter))
				enableone(JMmeanFilter,JBmeanFilter);
							
			else if((event.getSource()==JMmedianFilter) || (event.getSource()==JBmedianFilter))
				enableone(JMmedianFilter,JBmedianFilter);
			
			else if((event.getSource()==JMscale) || (event.getSource()==JBscale))
				enableone(JMscale,JBscale);
			
			else if((event.getSource()==JMsetColorXY) || (event.getSource()==JBsetColorXY))
				enableone(JMsetColorXY,JBsetColorXY);	
				
		else if(event.getSource()==JBaddtext)
		{
			int temp=getIndexOfNumImage(currentWin);
			
			Viewer vo=(Viewer)allimages.elementAt(temp);
			
			new Main(vo.sendimg(),temp);
		}
		/*
	

		else if(event.getSource()==JBcompression)
		{
			ImageBrightness ib=new ImageBrightness();
			if(ImgArea.imageLoaded)
				ib.enableSlider(true);
		}
		else if(event.getSource()==JBresize)
		{
			if(ImgArea.imageLoaded)
			{
				ia.setActionCompressed(true);
				enableSaving(true);
			}
		}
		else if(event.getSource()==JBrotate)
		{
			ImageResize ir=new ImageResize();
			if(ImgArea.imageLoaded)
			{
				ir.enableComponents(true);
			}
		}
		else if(event.getSource()==JBtransparency)
		{
			if(ImgArea.imageLoaded)
			{
				ia.rotateImage();
				enableSaving(true);
			}
		}
		
		else if(event.getSource()==JBbright)
		{
			if(ImgArea.c==null)
			{
				JOptionPane dialog=new JOptionPane();
				dialog.showMessageDialog(this,"Click the background area of the image first ","Error",JOptionPane.ERROR_MESSAGE);
				 
			}
			else 
			if(ImgArea.imageLoaded)
			{
				ia.makeTransparency(ImgArea.c);
				enableSaving(true);
			}
		}
		else if(event.getSource()==JBreset)
		{
			ia.setImageFileName(filename);
			ia.reset();
		}
		*/
		
		}
				
	private int getIndexOfNumImage(int ind)
	{
		System.out.print("\n array size="+allimages.size()+":-");
		for(int i=0;i<allimages.size();i++)
		{
		Viewer viewnow=(Viewer)allimages.elementAt(i);
		System.out.print("\n \n loop"+i+"//////"+viewnow.winNum+"////\n");
			if(viewnow.winNum==ind)
			{
				return i;
			}
		}				
		return -1;
	}
	public String FileChose()
	{
		JFileChooser fc=new JFileChooser();
		fc.setAcceptAllFileFilterUsed(true);
		int returnVal=fc.showDialog(this,"Open Image");
		if(returnVal == JFileChooser.APPROVE_OPTION)
		{
			return fc.getSelectedFile().toString();
		}
		else
		{
			return "-1";
		}
	}
	public void mouseDragged(MouseEvent e)
	{	
	}
	
	public void mouseReleased(MouseEvent e)
	{	
	}
	public void mouseMoved(MouseEvent e)
	{	
	}
	public void mousePressed(MouseEvent e)
	{	
	}
	public void componentMoved(ComponentEvent e)
	{	
	}
	public void componentHidden(ComponentEvent e)
	{	
	}
	
	public void componentResized(ComponentEvent e)
	{	
	}
	public void componentShown(ComponentEvent e)
	{	
	}
	public void mouseEntered(MouseEvent e)
	{	
	}
	public void mouseExited(MouseEvent e)
	{	
	}
	public void mouseClicked(MouseEvent e)
	{	
	}
	public static void main(String args[])
	{
		new ProspecT();
	}	
	
}
