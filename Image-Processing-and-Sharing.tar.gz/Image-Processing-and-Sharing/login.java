import java.io.*;
import java.awt.*;
import javax.awt.event.*;
import javax.swing.*;

class baZIra extends JFrame implements MouseMotionListener,MouseListener
{

	public void mouseDragged(MouseEvent e)
	{	
	}
	
	public void mouseReleased(MouseEvent e)
	{	
	}
	public void mouseMoved(MouseEvent e)
	{	
	}
	public void mousePressed(MouseEvent e)
	{	
	}
	public void componentMoved(ComponentEvent e)
	{	
	}
	public void componentHidden(ComponentEvent e)
	{	
	}
	
	public void componentResized(ComponentEvent e)
	{	
	}
	public void componentShown(ComponentEvent e)
	{	
	}
	public void mouseEntered(MouseEvent e)
	{	
	}
	public void mouseExited(MouseEvent e)
	{	
	}
	public void mouseClicked(MouseEvent e)
	{	
	}
	public static void main(String args[])
	{
		new baZIra();
	}	
	
}
