import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.awt.event.*;
import java.awt.*;
import java.util.*;

public class Client extends JFrame
{
	public Client()
	{
		initComponents();
	}
	@SuppressWarnings("unchecked")
	private void initComponents()
	{
		jLabel1=new JLabel();
		jButton1=new JButton();
		jScrollPane=new JScrollPane();
		txt=new JTextArea();
		jButton2=new JButton();
		txtName=new JTextField();
		jComboBox1=new JComboBox<>();
		txtIp=new JTextField();
		jLabel2=new JLabel();
		
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		
		jLabel1.setFont(new Font("sansserif",1,18));
		jLabel1.setText("Client");
		
		jButton1.setText("Connect");
		
		jButton1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent evt)
			{
				jButton1ActionPerformed(evt);
			}
		});
		txt.setEditable(false);
		txt.setColumns(20);
		txt.setRows(5);
		jScrollPane.setViewportView(txt);
		
		jButton2.setText("Send Photo");
		jButton2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent evt)
			{
				jButton2ActionPerformed(evt);
			}
		});
		
		jComboBox1.setModel(new DefaultComboBoxModel<>(new String[] { "Image","File"}));
		jLabel2.setText("IP");
		GroupLayout layout=new GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(
			layout.createParallelGroup(GroupLayout.Alignment.LEADING)
			.addGroup(layout.createSequentialGroup()
			.addComponent(jLabel1)
			.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED,GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE)
			.addComponent(jLabel2,GroupLayout.PREFERRED_SIZE,32,GroupLayout.PREFERRED_SIZE)
			.addGap(18,18,18).addComponent(txtIp,GroupLayout.PREFERRED_SIZE,127,GroupLayout.PREFERRED_SIZE).addGap(18,18,18).addComponent(jButton1)
			.addGap(18,18,18))
			.addGroup(layout.createSequentialGroup()
			.addContainerGap()
			.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
			.addComponent(jScrollPane,GroupLayout.DEFAULT_SIZE,601,Short.MAX_VALUE)
			.addGroup(layout.createSequentialGroup()
			.addComponent(jComboBox1,GroupLayout.PREFERRED_SIZE,GroupLayout.DEFAULT_SIZE,GroupLayout.PREFERRED_SIZE)
			.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
			.addComponent(jButton2)
			.addGap(18,18,18)
			.addComponent(txtName,GroupLayout.PREFERRED_SIZE,306,GroupLayout.PREFERRED_SIZE)
			.addGap(0,0,Short.MAX_VALUE)))
			.addContainerGap())
			);
			
			layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(jLabel1).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(jButton1).addComponent(txtIp,GroupLayout.PREFERRED_SIZE,GroupLayout.DEFAULT_SIZE,GroupLayout.PREFERRED_SIZE).addComponent(jLabel2)))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
			.addComponent(jScrollPane,GroupLayout.PREFERRED_SIZE,210,GroupLayout.PREFERRED_SIZE)
			.addGap(26,26,26)
			.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
			.addComponent(jButton2)
			.addComponent(txtName,GroupLayout.PREFERRED_SIZE,GroupLayout.DEFAULT_SIZE,GroupLayout.PREFERRED_SIZE)
			.addComponent(jComboBox1,GroupLayout.PREFERRED_SIZE,GroupLayout.DEFAULT_SIZE,GroupLayout.PREFERRED_SIZE))
			.addGap(0,63,Short.MAX_VALUE))
			);
			pack();
			setLocationRelativeTo(null);
			
			}
			private Socket socket;
			private ObjectOutputStream out;
			
			private void jButton1ActionPerformed(ActionEvent evt)
			{
				try
				{
					socket=new Socket(txtIp.getText().trim(),9999);
					txt.append("Connect success ...");
					out=new ObjectOutputStream(socket.getOutputStream());
					Data data=new Data();
					data.setStatus("new");
					data.setName("Laing raven");
					out.writeObject(data);
					out.flush();
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(this,e,"Error",JOptionPane.ERROR_MESSAGE);
				}
			}
			
			private void jButton2ActionPerformed(ActionEvent evt)
			{
				try
				{
					JFileChooser ch=new JFileChooser();
					int c=ch.showOpenDialog(this);
					if(c==JFileChooser.APPROVE_OPTION)
					{
						File f=ch.getSelectedFile();
						FileInputStream in=new FileInputStream(f);
						byte b[]=new byte[in.available()];
						in.read(b);
						Data data=new Data();
						data.setStatus(jComboBox1.getSelectedItem()+"");
						data.setName(txtName.getText().trim());
						data.setFile(b);
						out.writeObject(data);
						out.flush();
						txt.append("send 1 file../n");	
					}
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(this,e,"Error",JOptionPane.ERROR_MESSAGE);
				}
			}
			
			
			private JButton jButton1;
			private JButton jButton2;
			private JComboBox<String> jComboBox1;
			private JLabel jLabel1;
			private JLabel jLabel2;
			private JScrollPane jScrollPane;
			private JTextArea txt;
			private JTextField txtIp;
			private JTextField txtName;
} 

class ClientMachine{

			ClientMachine(String args[])
			{
				try
				{
					for(UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
					{
						if("Nimbus".equals(info.getName()))
						{
							UIManager.setLookAndFeel(info.getClassName());
							break;
						}
					}				
				}
				catch(ClassNotFoundException ex)
				{
					java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
				}
				catch(InstantiationException ex)
				{
					java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
				}
				catch(IllegalAccessException ex)
				{
					java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
				}
				catch(UnsupportedLookAndFeelException ex)
				{
					java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
				}
				
				EventQueue.invokeLater(new Runnable()
				{
					public void run()
					{
						new Client().setVisible(true);
					}
				});
			}
}
