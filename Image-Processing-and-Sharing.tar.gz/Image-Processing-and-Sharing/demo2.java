import java.awt.*;
import javax.swing.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import javax.swing.event.*;
import javax.imageio.stream.*;

public class drawTest extends JPanel{

	public void paint(Graphics g)
	{
		Image img =createImageWithText();
		g.drawImage(img,20,20,this);
	}
	private Image createImageWithtext()
	{
		BufferedImage bufferedImage=new BufferedImage(1280,800,BufferedImage.TYPE_INT_RGB);
		Graphics g=bufferedImage.getGraphics();
		try{
			bufferedImage=ImageIO.read(getClass().getResource("/exports/TYBG22/TYBG22/effects-or-choose-colour.jpg"));
		}
		catch(IOException e){
			e.printStackTrace();			
		}
		g.drawString("Point is here",20,20);
		return bufferedImage;
	}
	public static void main(String[] args){
		JFrame frame=new JFrame();
		Dimension screenSize = Toolkit.getDefaultToolkit().getDcreenSize();
		double width=screenSize.getWidth();
		double height=screenSize.getHeight();
		frame.getContentPane().add(new drawTest());
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		System.out.println(height+" "+width);
		frame.setVisible(true);
		
	}	
}

