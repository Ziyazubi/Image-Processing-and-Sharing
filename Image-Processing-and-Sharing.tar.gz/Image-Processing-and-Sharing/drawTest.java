import java.awt.*;
import javax.swing.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import javax.swing.event.*;
import javax.imageio.stream.*;

public class drawTest extends JPanel{

	public void paintComponent(Graphics g)
	{
		try{
		Image img =createImageWithText();
		
		}
		catch(Exception e)
		{}
	}
	private Image createImageWithText()throws IOException
	{
		BufferedImage bufferedImage=ImageIO.read(getClass().getResource("mm7.jpg"));
		Graphics g=bufferedImage.getGraphics();
		
		g.drawString("Point is here",20,20);
		
		g.drawImage(bufferedImage,20,20,this);
		g.dispose();
		
		return bufferedImage;
	}
	public static void main(String[] args){
		JFrame frame=new JFrame();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		double width=screenSize.getWidth();
		double height=screenSize.getHeight();
		frame.getContentPane().add(new drawTest());
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		System.out.println(height+" "+width);
		frame.setVisible(true);
		
	}	
}

