
import java.io.*;
import java.net.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.logging.*;
class Server extends JFrame{
	
	Server(){
	initComponents();
	}
	@SuppressWarnings("unchecked")
	
	private void initComponents(){
		jLabel1=new JLabel();
		jButton1=new JButton();
		jScrollPane1=new JScrollPane();
		txt=new JTextArea();
		jScrollPane2=new JScrollPane();
		list=new JList<>();
		
		jButton2=new JButton();
		jButton3=new JButton();
		
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		jLabel1.setFont(new Font("sanserif",1,18));
		jLabel1.setText("RECIVE IMAGE");
		jButton1.setText("Start Reciving");
		jButton1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent evt){
			jButton1ActionPerformed(evt);
			}
		});
		txt.setEditable(false);
		txt.setColumns(20);
		txt.setRows(5);
		jScrollPane1.setViewportView(txt);
		
		list.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent evt)
			{
			listMouseClicked(evt);
			}
		});
		jScrollPane2.setViewportView(list);
		jButton2.setText("Open");
		jButton2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent evt){
			jButton2ActionPerformed(evt);
			}
		});
		
		jButton3.setText("Save");
		jButton3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent evt){
			jButton3ActionPerformed(evt);
			}
		});
		
		GroupLayout layout=new GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		
		layout.setHorizontalGroup(
		layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(jLabel1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED,GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE).addComponent(jButton1)).addGroup(layout.createSequentialGroup().addComponent(jScrollPane1,GroupLayout.PREFERRED_SIZE,377,GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(jButton2,GroupLayout.PREFERRED_SIZE,83,GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(jButton3,GroupLayout.PREFERRED_SIZE,85,GroupLayout.PREFERRED_SIZE)).addComponent(jScrollPane2,GroupLayout.PREFERRED_SIZE,0,Short.MAX_VALUE)))).addContainerGap())
		);
		
		
		layout.setVerticalGroup(
		layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(jLabel1).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(jButton1))).addGap(23,23,23).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING,false).addComponent
(jScrollPane2,GroupLayout.DEFAULT_SIZE,271,Short.MAX_VALUE).addComponent(jScrollPane1)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED,GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(jButton2).addComponent(jButton3)).addContainerGap()));
		pack();
		setLocationRelativeTo(null);
	}
	private ServerSocket server;
	private ObjectOutputStream out;
	private ObjectInputStream in;
	private DefaultListModel mod=new DefaultListModel();

	private void jButton1ActionPerformed(ActionEvent evt)
	{
		list.setModel(mod);
		new Thread(new Runnable(){
		@Override
		public void run(){
			try{
				server=new ServerSocket(9999);
				txt.append("Server Starting....\n");
				Socket s=server.accept();
				in=new ObjectInputStream(s.getInputStream());
				Data data=(Data)in.readObject();
				String name=data.getName();
				txt.append("New Client"+name+"Has Been Connected....\n");
				while(true)
				{
					data=(Data)in.readObject();
					mod.addElement(data);
					txt.append("Get 1 File....\n");
				}
			}
			catch(Exception e){
			JOptionPane.showMessageDialog(Server.this,JOptionPane.ERROR_MESSAGE);
			}
		}
		}).start();
	}
	private void listMouseClicked(MouseEvent evt){
		if(evt.getClickCount()==2){
			if(!list.isSelectionEmpty()){
				if(SwingUtilities.isLeftMouseButton(evt))
				{
					open();
				}
				else if(SwingUtilities.isRightMouseButton(evt)){
					save();
				}
			}
		}
	}
	private void open(){
		Data data=(Data)mod.getElementAt(list.getSelectedIndex());
		if(data.getStatus().equals("Image")){
			ShowImage obj=new ShowImage(this,true);
			ImageIcon icon=new ImageIcon(data.getFile());
			obj.set(icon);
			obj.setVisible(true);
		}
	}
	private void save(){
		Data data=(Data)mod.getElementAt(list.getSelectedIndex());
		JFileChooser ch=new JFileChooser();
		int c=ch.showSaveDialog(this);
		if(c==JFileChooser.APPROVE_OPTION)
		{
			try{
			FileOutputStream out=new FileOutputStream(ch.getSelectedFile());
			out.write(data.getFile());
			out.close();
			
			}
			catch(Exception e)
			{
			JOptionPane.showMessageDialog(this,e,"Error",JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	private void jButton3ActionPerformed(ActionEvent evt)
	{
		if(!list.isSelectionEmpty())
		{
			save();
		}
	}
	private void jButton2ActionPerformed(ActionEvent evt)
	{
		if(!list.isSelectionEmpty())
		{
			open();
		}
	}	
	
	
	
	private JButton jButton1;
	private JButton jButton2;
	private JButton jButton3;
	private JLabel jLabel1;
	private JScrollPane jScrollPane1;
	private JScrollPane jScrollPane2;
	private JList<String> list;
	private JTextArea txt;
}
public class ServerMachine{
	
	public ServerMachine()
	{
		try
		{
			for(UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
			{
				if("Nimbus".equals(info.getName()))
				{
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		}
		catch(ClassNotFoundException ex)
		{
			java.util.logging.Logger.getLogger(Server.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
		}
		
		catch(InstantiationException ex)
		{
			java.util.logging.Logger.getLogger(Server.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
		}
		
		catch(IllegalAccessException ex)
		{
			java.util.logging.Logger.getLogger(Server.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
		}
		
		catch(UnsupportedLookAndFeelException ex)
		{
			java.util.logging.Logger.getLogger(Server.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
		}
		
		EventQueue.invokeLater(new Runnable(){
			public void run()
			{
				new Server().setVisible(true);
			}
		});
	}
}





